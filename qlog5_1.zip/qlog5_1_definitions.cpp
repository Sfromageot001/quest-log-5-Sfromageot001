#include "qlog5_1_tryingAgain.h"
#include <iostream>
#include <iomanip>

int BinTreeNode::getData() {
    return data;
}

void BinTreeNode::setData(int data) {
    data = data;
}

BinTreeNode* BinTreeNode::getLeft() {
    return left;
}

void BinTreeNode::setLeft(BinTreeNode* node) {
    left = node;
}

BinTreeNode* BinTreeNode::getRight() {
    return right;
}

void BinTreeNode::setRight(BinTreeNode* node) {
    right = node;
}

BinTreeNode* BinTreeNode::getParent() {
    return parent;
}
void BinTreeNode::setParent(BinTreeNode* node) {
    parent = node;
}

void BinTree::insert(int data) {
    BinTreeNode* newNode = new BinTreeNode(data);
    if (getRootNode() == nullptr) {
        setRootNode(newNode);
        setIndex(newNode);
    }
    else {
        BinTreeNode* current = getRootNode();
        while (true) {
            if (data < current->data) {
                if (current->left == nullptr) {
                    current->left = newNode;
                    newNode->parent = current;
                    break;
                }
                else {
                    current = current->left;
                }
            }
            else {
                if (current->right == nullptr) {
                    current->right = newNode;
                    newNode->parent = current;
                    break;
                }
                else {
                    current = current->right;
                }
            }
        }
    }
    size++;
};
    
void BinTree::printTree(BinTreeNode* root, int indent ) {
    if (root == nullptr) {
        return;
    }

    const int spacing = 4;
    if (root->right != nullptr) {
        printTree(root->right, indent + spacing);
    }

    std::cout << std::setw(indent) << ' ';
    if (root->right != nullptr) {
        std::cout << " /\n" << std::setw(indent) << ' ';
    }
    std::cout << root->data << "\n";

    if (root->left != nullptr) {
        std::cout << std::setw(indent) << ' ' << " \\\n";
        printTree(root->left, indent + spacing);
    }
}

// Usage example:
// BinTree tree;
// tree.insert(5);
// tree.insert(3);
// tree.insert(8);
// tree.insert(2);
// tree.insert(4);
// tree.insert(7);
// tree.insert(9);
// printTree(tree.getRootNode());


    


