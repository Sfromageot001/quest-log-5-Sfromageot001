#include <iostream>
#include <iomanip>
#include "QLog5.h"
using namespace std;



int BinTreeNode::getData() {
    return data;
}

void BinTreeNode::setData(int data) {
    data = data;
}

BinTreeNode* BinTreeNode::getLeft() {
    return left;
}

void BinTreeNode::setLeft(BinTreeNode* node) {
    left = node;
}

BinTreeNode* BinTreeNode::getRight() {
    return right;
}

void BinTreeNode::setRight(BinTreeNode* node) {
    right = node;
}

BinTreeNode* BinTreeNode::getParent() {
    return parent;
}
void BinTreeNode::setParent(BinTreeNode* node) {
    parent = node;
}

void BinTree::insert(int data) {
    BinTreeNode* newNode = new BinTreeNode(data);
    if (getRootNode() == nullptr) {
        setRootNode(newNode);
        setIndex(newNode);
    }
    else {
        BinTreeNode* current = getRootNode();
        while (true) {
            if (data < current->data) {
                if (current->left == nullptr) {
                    current->left = newNode;
                    newNode->parent = current;
                    break;
                }
                else {
                    current = current->left;
                }
            }
            else {
                if (current->right == nullptr) {
                    current->right = newNode;
                    newNode->parent = current;
                    break;
                }
                else {
                    current = current->right;
                }
            }
        }
    }
    size++;
};

void BinTree::printTree(BinTreeNode* root, int indent) {
    if (root == nullptr) {
        return;
    }

    const int spacing = 4;
    if (root->right != nullptr) {
        printTree(root->right, indent + spacing);
    }

    std::cout << std::setw(indent) << ' ';
    if (root->right != nullptr) {
        std::cout << " /\n" << std::setw(indent) << ' ';
    }
    std::cout << root->data << "\n";

    if (root->left != nullptr) {
        std::cout << std::setw(indent) << ' ' << " \\\n";
        printTree(root->left, indent + spacing);
    }
}

void BinTree::printPreorder(BinTreeNode* root) {
    if (root == nullptr) {
        return;
    }

    std::cout << root->data << " ";
    printPreorder(root->left);
    printPreorder(root->right);
}

void BinTree::printInorder(BinTreeNode* root) {
    if (root == nullptr) {
        return;
    }

    printInorder(root->left);
    std::cout << root->data << " ";
    printInorder(root->right);
}

void BinTree::printPostorder(BinTreeNode* root) {
    if (root == nullptr) {
        return;
    }

    printPostorder(root->left);
    printPostorder(root->right);
    std::cout << root->data << " ";
}







