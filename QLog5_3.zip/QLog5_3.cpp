#pragma once
#include <iostream>
#include <iomanip>
#include "QLog5_3.h"
using namespace std;
int main() {
    BinTree tree;
    tree.insert(5);
    tree.insert(3);
    tree.insert(7);
    tree.insert(1);
    tree.insert(4);
    tree.insert(12);
    tree.insert(24);
    tree.insert(82);
    tree.insert(50);
    tree.insert(29);
    tree.insert(6);
    tree.insert(22);
    tree.insert(51);


    tree.printTree(tree.getRootNode(), 3);

    std::cout << "Preorder traversal: ";
    tree.printPreorder(tree.getRootNode());
    std::cout << std::endl;

    std::cout << "Inorder traversal: ";
    tree.printInorder(tree.getRootNode());
    std::cout << std::endl;

    std::cout << "Postorder traversal: ";
    tree.printPostorder(tree.getRootNode());
    std::cout << std::endl;

    



    std::cout << "Size of the tree: " << tree.getSize() << std::endl;

    return 0;
}
