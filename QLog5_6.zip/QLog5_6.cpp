#pragma once
#include <iostream>
#include <iomanip>
#include "QLog5_6.h"
#include "QLog5_6_MaxHeap.h"
using namespace std;
int main() {
    BinTree tree;
    tree.insert(5);
    tree.insert(3);
    tree.insert(7);
    tree.insert(1);
    tree.insert(4);
    tree.insert(12);
    tree.insert(24);
    tree.insert(82);
    tree.insert(50);
    tree.insert(29);
    tree.insert(6);
    tree.insert(22);
    tree.insert(51);


    std::cout << "ORIGINAL TREE:" << std::endl;

    tree.printTree(tree.getRootNode(), 3);

    std::cout << "Preorder traversal: ";
    tree.printPreorder(tree.getRootNode());
    std::cout << std::endl;

    std::cout << "Inorder traversal: ";
    tree.printInorder(tree.getRootNode());
    std::cout << std::endl;

    std::cout << "Postorder traversal: ";
    tree.printPostorder(tree.getRootNode());
    std::cout << std::endl;

    std::cout << "Size of the tree: " << tree.getSize() << std::endl<<std::endl;

    MaxHeap maxHeapDown;
    maxHeapDown.insert(5);
    maxHeapDown.insert(3);
    maxHeapDown.insert(7);
    maxHeapDown.insert(1);
    maxHeapDown.insert(4);
    maxHeapDown.insert(12);
    maxHeapDown.insert(24);
    maxHeapDown.insert(82);
    maxHeapDown.insert(50);
    maxHeapDown.insert(29);
    maxHeapDown.insert(6);
    maxHeapDown.insert(22);
    maxHeapDown.insert(51);
    
    
    

    // Demonstrate MaxHeapDown 
    BinTreeNode* node = maxHeapDown.getRootNode();
    maxHeapDown.MaxHeapDown(node);
    std::cout << "Tree after MaxHeap down:" << std::endl;
    maxHeapDown.printTree(maxHeapDown.getRootNode(), 3);
    cout<<std::endl << std::endl;
   
    MaxHeap maxHeapUp;
    maxHeapUp.insert(5);
    maxHeapUp.insert(3);
    maxHeapUp.insert(7);
    maxHeapUp.insert(1);
    maxHeapUp.insert(4);
    maxHeapUp.insert(12);
    maxHeapUp.insert(24);
    maxHeapUp.insert(82);
    maxHeapUp.insert(50);
    maxHeapUp.insert(29);
    maxHeapUp.insert(6);
    maxHeapUp.insert(22);
    maxHeapUp.insert(51);



    
    maxHeapUp.MaxHeapUp(maxHeapUp.getRootNode()->getRight()->getRight()->getRight()->getRight());

    cout << "After MaxHeapUp using node 82: "<<endl;
    maxHeapUp.printTree(maxHeapUp.getRootNode(),3);
    cout << endl << endl;

    // Demonstrate Delete(Node) function
    BinTreeNode* nodeToDelete = maxHeapUp.getRootNode()->getRight()->getRight()->getRight()->getRight(); // Choose a node to delete
    maxHeapUp.Delete(nodeToDelete);

    cout << "After deleting node 82:" << endl;

    maxHeapUp.printTree(maxHeapUp.getRootNode(), 3);
    cout << endl;


   
}
