#pragma once
#include <iostream>
#include <iomanip>
using namespace std;
class BinTreeNode {
public:
    int data;
    BinTreeNode* left;
    BinTreeNode* right;
    BinTreeNode* parent;

    BinTreeNode(int data) {

        this->data = data;
        left = nullptr;
        right = nullptr;
        parent = nullptr;

    }



    // Getter method for data
    int getData();

    // Setter method for val
    void setData(int data);

    // Getter method for left child
    BinTreeNode* getLeft();

    // Setter method for left child
    void setLeft(BinTreeNode* node);

    // Getter method for right child
    BinTreeNode* getRight();

    // Setter method for right child
    void setRight(BinTreeNode* node);

    // Getter method for parent
    BinTreeNode* getParent();

    // Setter method for parent
    void setParent(BinTreeNode* node);

};




class BinTree {
private:
    BinTreeNode* rootNode;
    BinTreeNode* index;
    int size;


public:


    BinTree() : rootNode(nullptr), index(nullptr), size(0) {}

    // Getter method for rootNode
    BinTreeNode* getRootNode() {
        return rootNode;
    }

    // Setter method for rootNode
    void setRootNode(BinTreeNode* node) {
        rootNode = node;
    }

    // Getter method for index
    BinTreeNode* getIndex() {
        return index;
    }

    // Setter method for index
    void setIndex(BinTreeNode* node) {
        index = node;
    }

    // Getter method for size
    int getSize() {
        return size;
    }

    //insert new node into tree
    void insert(int data);


    void printTree(BinTreeNode* root, int indent);

    //TRAVERSALS
    void printPreorder(BinTreeNode* root);
    void printInorder(BinTreeNode* root);
    void printPostorder(BinTreeNode* root);



};


#pragma once
