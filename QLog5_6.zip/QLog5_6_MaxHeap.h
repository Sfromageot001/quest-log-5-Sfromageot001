#pragma once
#include "QLog5_6.h"
#include "QLOg5_6_MaxHeap.h"

class MaxHeap : public BinTree {
public:
    MaxHeap() : BinTree() {} // Constructor

    void MaxHeapDown(BinTreeNode* node);
    void MaxHeapUp(BinTreeNode* node);
};
